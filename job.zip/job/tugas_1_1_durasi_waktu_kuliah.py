print("afandi")
print("Durasi Waktu Perkuliahan\n")
print("Jam Mulainya Perkuliahan\n")
awaljam = int(input(" jam : "))
awalmenit = int(input(" menit : "))
awaldetik = int(input(" detik : "))

awalseluruh = awaldetik + (awaljam * 3600) + (awalmenit * 60)
print("\n")
print("Jam Berakhirnya Perkuliahan\n")
akhirjam = int(input(" jam : "))
akhirmenit = int(input(" menit : "))
akhirdetik = int(input(" detik : "))
print("\n")
akhirseluruh = akhirdetik + (akhirjam * 3600) + (akhirmenit * 60)
seluruhwaktu = akhirseluruh - awalseluruh

#mengembalikan format jam ke semula

jam = seluruhwaktu // 3600
sisadetik = seluruhwaktu % 3600
menit = sisadetik // 60
detik = sisadetik % 60
print("Jumlah Durasi Waktu Perkuliahan Adalah\n")
print("jam : %d jam" % jam)
print("menit : %d menit" % menit)
print("detik : %d detik" % detik)
print("\n")
