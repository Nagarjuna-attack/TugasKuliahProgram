print("Program Menghitung Jumlah Lembaran Uang")
uang = int(input("masukkan Jumlah uang : Rp."))
seratus = uang // 100000
uang = uang % 100000
limapuluh = uang // 50000
uang = uang % 50000
duapuluh = uang // 20000
uang = uang % 20000
sepuluh = uang // 10000
uang = uang % 10000
limaribu = uang // 5000
uang = uang % 5000
duaribu = uang // 2000
uang = uang % 2000
seribu = uang // 1000
uang = uang % 1000
gope = uang // 500
uang = uang % 500
duart = uang // 200
uang = uang % 200
saturt = uang // 100
#menghitung lembaran
lembaran = seratus + limapuluh + duapuluh + sepuluh + limaribu + duaribu + seribu
keping = gope + duart + saturt

#cetak hasilnya
print("\n")
print("Pecahan Rp. 100 Ribu : %d" % seratus)
print("Pecahan Rp. 50 Ribu : %d" % limapuluh)
print("Pecahan Rp. 20 Ribu : %d" % duapuluh)
print("Pecahan Rp. 10 Ribu : %d" % sepuluh)
print("Pecahan Rp. 5 Ribu : %d" % limaribu)
print("Pecahan Rp. 2 Ribu : %d" % duaribu)
print("Pecahan Rp. SeRibu : %d" % seribu)
print("Pecahan Rp. 500 : %d" % gope)
print("Pecahan Rp. 200 : %d" % duart)
print("Pecahan Rp. 100 : %d" % saturt)

print("Jumlah Lembaran : %d " % lembaran)
print("Jumlah Keping : %d " % keping)
