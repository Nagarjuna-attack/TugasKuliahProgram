def inputData(data):
    x = int(input(" Masukkan %s " % data))
    return x


def validasi(nilai, kedua):
    nl = nilai * kedua
    return nl


def inbiodata(y):
    x = raw_input("Masukkan %s" % y)
    return x


def nilaiHuruf(x):
    if x >= 80:
        huruf = "A"
        return huruf
    elif 80 > x and x >= 65:
        huruf = "B"
        return huruf
    elif 65 > x and x >= 50:
        huruf = "C"
        return huruf
    elif 50 > x and x >= 40:
        huruf = "D"
        return huruf
    elif x < 40:
        huruf = "E"
        return huruf


def keterangan(ket):
    if ket == "A" or ket == "B" or ket == "C" or ket == "D":
        keterangan = "LULUS"
        return keterangan
    elif ket == "E":
        keterangan = "TIDAK LULUS"
        return keterangan