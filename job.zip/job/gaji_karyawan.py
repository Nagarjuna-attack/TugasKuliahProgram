#Program Untuk Menghitung Gaji Karyawan
countkaryawan = countpria = countwanita = countmenikah = countduda = 0
countjanda = countlajang = counts1 = countd3 = countsma = gajiterbesar = totpajak = 0
while 1:
    countkaryawan += 1
    nama = raw_input("\nMasukkan nama : ")
    nik = raw_input("Masukkan NIK  : ")
    golongan = raw_input("\nMasukkan Golongan [I/II/III]  : ")
    masakerja = input("Masukkan Masa Kerja [0..40]  : ")
    if golongan == "I" and masakerja <= 10:
        gajipokok = 500000
    elif golongan == "I" and (masakerja > 10 and masakerja <= 40):
        gajipokok = 800000
    elif golongan == "II" and masakerja <= 10:
        gajipokok = 700000
    elif golongan == "II" and (masakerja > 10 and masakerja <= 40):
        gajipokok = 1000000
    elif golongan == "III" and masakerja <= 10:
        gajipokok = 900000
    elif golongan == "III" and (masakerja > 10 and masakerja <= 40):
        gajipokok = 1200000
    print("\nGaji Pokok  : Rp. %d" % gajipokok)
    jenkel = raw_input("\nMasukkan Jenis Kelamin [P=pria/W=wanita] : ")
    if jenkel == "P":
        countpria += 1
    elif jenkel == "W":
        countwanita += 1
    status = raw_input(
        "Masukkan Status Perkawinan [M=menikah/T=tidak/D=duda/J=janda]: ")
    tanak = 0
    if status == "M":
        countmenikah += 1
    elif status == "T":
        countlajang += 1
    elif status == "D":
        countduda += 1
    elif status == "J":
        countjanda += 1
    if status == "M" or status == "D" or status == "J":
        jumanak = input("Masukkan Jumlah Anak : ")
        if status == "M":
            tkel = 0.1 * gajipokok
            if jumanak <= 3:
                tanak = (0.05 * gajipokok) * jumanak
            else:
                tanak = (0.05 * gajipokok) * 3
        elif status == "D" or status == "J":
            tkel = 0.15 * gajipokok
            if jumanak <= 3:
                tanak = (0.07 * gajipokok) * jumanak
            else:
                tanak = (0.07 * gajipokok) * 3
    elif status == "T":
        tkel = 0.05 * gajipokok
    print("\nTunjangan Anak     : Rp. %d" % tanak)
    print("\nTunjangan Keluarga : Rp. %d" % tkel)
    tingpen = raw_input("\nMasukkan Tingkat Pendidikan [S1/D3/SMA] : ")
    if tingpen == "S1":
        tunpen = 0.15 * gajipokok
        counts1 += 1
    elif tingpen == "D3":
        tunpen = 0.1 * gajipokok
        countd3 += 1
    elif tingpen == "SMA":
        tunpen = 0.1 * gajipokok
        countsma += 1
    print("\nTunjangan Pendidikan  : Rp. %d" % tunpen)
    kodejab = raw_input("\nMasukkan Kode Jabatan [x/y/z] : ")

    if kodejab == "x":
        tunjab = 0.05 * gajipokok
    elif kodejab == "y":
        tunjab = 0.015 * gajipokok
    elif kodejab == "z":
        tunjab = 0.03 * gajipokok
    tunberas = 550000
    tuntrans = 600000

    print("\nTujangan Jabatan    : Rp. %d" % tunjab)
    print("Tujangan Beras        : Rp. %d" % tunberas)
    print("Tujangan Transportasi : Rp. %d" % tuntrans)
    jamnormal = 200
    tamgaji = 0
    potgaji = 0
    if kodejab == "x":
        potkoperasi = 50000
    if kodejab == "y" or kodejab == "z":
        potkoperasi = 20000
    jamker = input("\nMasukkan Jumlah Jam Kerja : ")
    if jamker > jamnormal:
        tamgaji = (0.02 * gajipokok) * (jamker - jamnormal)
    elif jamker < jamnormal:
        potgaji = (0.01 * gajipokok) * (jamnormal - jamker)
    print("\nTambahan Gaji   : Rp. %d" % tamgaji)
    print("Potongan Gaji     : Rp. %d" % potgaji)
    print("Potongan Koperasi : Rp. %d" % potkoperasi)
    jumpinjam = input("\nMasukkan Jumlah Pinjaman : ")
    potpinjam = 0.1 * jumpinjam
    gajikotor = (gajipokok + tanak + tkel + tunpen + tunjab + tunberas +
                 tuntrans + tamgaji) - (potgaji + potkoperasi + potpinjam)
    if gajikotor < 1500000:
        pajak = 0.025 * gajikotor
    elif gajikotor > 1500000 and gajikotor < 2500000:
        pajak = 0.04 * gajikotor
    elif gajikotor > 2500000:
        pajak = 0.05 * gajikotor
    totpajak += pajak
    gajibersih = gajikotor - pajak
    if gajibersih > gajiterbesar:
        gajiterbesar = gajibersih
    print("\nPotongan Pinjaman : Rp. %d" % potpinjam)
    print("\nGaji Kotor        : Rp. %d" % gajikotor)
    print("Pajak               : Rp. %d" % pajak)
    print("Gaji Bersih         : Rp. %d" % gajibersih)
    kondisi = raw_input("\n\nAda Data Lagi..? [y/t] : ")
    if kondisi == "t":
        break
else:
    print("\n")
print("REKAPITULASI DATA")
print("\nJumlah Karyawan : %d" % countkaryawan)
print("\nPria    : %d" % countpria)
print("Wanita  : %d" % countwanita)
print("Menikah : %d" % countmenikah)
print("Duda    : %d" % countduda)
print("Janda   : %d" % countjanda)
print("Lajang  : %d" % countlajang)
print("S1      : %d" % counts1)
print("D3      : %d" % countd3)
print("SMA     : %d" % countsma)
print("\nTotal Pajak : Rp. %d" % totpajak)
print("Gaji Terbesar : Rp. %d" % gajiterbesar)
