def inputan(x):
    y = int(input("Masukkan %s" % x))
    return y


def output(data):
    data = data
    print("Hasil : \n")
    for g in range(0, len(data)):
        print("\t" + str(data[g]))
    print("\n")


def scaleBy():
    baris = inputan(" Jumlah Baris : ")
    colom = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    elemen = [[0 for x in range(colom)] for y in range(baris)]
    for i in range(len(elemen)):
        for j in range(len(elemen[0])):
            elemen[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for f in range(0, len(elemen)):
        print("\t" + str(elemen[f]))
    print("\n")
    scalar = inputan("Nilai Scalar : ")
    skalar = [[0 for x in range(colom)] for y in range(baris)]
    for k in range(0, len(elemen)):
        for l in range(0, len(elemen[0])):
            skalar[k][l] = elemen[k][l] * scalar
    return skalar


def transpose():
    baris = inputan(" Jumlah Baris : ")
    colom = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    elemen = [[0 for x in range(colom)] for y in range(baris)]
    for i in range(len(elemen)):
        for j in range(len(elemen[0])):
            elemen[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for f in range(0, len(elemen)):
        print("\t" + str(elemen[f]))
    print("\n")
    transpose = [[0 for x in range(baris)] for y in range(colom)]
    for i in range(len(elemen)):
        for j in range(len(elemen[0])):
            transpose[j][i] = elemen[i][j]
    return transpose


def add():
    print("Masukkan Ordo dan Element Matriks A : ")
    baris = inputan(" Jumlah Baris : ")
    colom = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    A = [[0 for x in range(colom)] for y in range(baris)]
    for i in range(len(A)):
        for j in range(len(A[0])):
            A[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for f in range(0, len(A)):
        print("\t" + str(A[f]))
    print("\n")
    print("Masukkan Ordo dan Element Matriks B : ")
    baris2 = inputan(" Jumlah Baris : ")
    colom2 = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    B = [[0 for x in range(colom2)] for y in range(baris2)]
    for i in range(len(B)):
        for j in range(len(B[0])):
            B[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for h in range(0, len(B)):
        print("\t" + str(B[h]))
    print("\n")
    C = [[0 for x in range(colom)] for y in range(baris)]
    for k in range(0, len(A)):
        for l in range(0, len(A[0])):
            C[k][l] = A[k][l] + B[k][l]
    return C


def subtract():
    print("Masukkan Ordo dan Element Matriks A : ")
    baris = inputan(" Jumlah Baris : ")
    colom = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    A = [[0 for x in range(colom)] for y in range(baris)]
    for i in range(len(A)):
        for j in range(len(A[0])):
            A[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for f in range(0, len(A)):
        print("\t" + str(A[f]))
    print("\n")
    print("Masukkan Ordo dan Element Matriks B : ")
    baris2 = inputan(" Jumlah Baris : ")
    colom2 = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    B = [[0 for x in range(colom2)] for y in range(baris2)]
    for i in range(len(B)):
        for j in range(len(B[0])):
            B[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for h in range(0, len(B)):
        print("\t" + str(B[h]))
    print("\n")
    C = [[0 for x in range(colom)] for y in range(baris)]
    for k in range(0, len(A)):
        for l in range(0, len(A[0])):
            C[k][l] = A[k][l] - B[k][l]
    return C


def multiply():
    print("Jumlah Kolom Matriks A == Baris Matriks B")
    print("Masukkan Ordo dan Element Matriks A : ")
    baris = inputan(" Jumlah Baris : ")
    colom = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    A = [[0 for x in range(baris)] for y in range(colom)]
    for i in range(len(A)):
        for j in range(len(A[0])):
            A[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for f in range(0, len(A)):
        print("\t" + str(A[f]))
    print("\n")
    print("Masukkan Ordo dan Element Matriks B : ")
    baris2 = inputan(" Jumlah Baris : ")
    colom2 = inputan(" Jumlah Colom : ")
    print("Masukkan Element Matriks : ")
    B = [[0 for x in range(baris2)] for y in range(colom2)]
    for i in range(len(B)):
        for j in range(len(B[0])):
            B[i][j] = inputan("Elemen %d,%d : " % (i, j))
    print("\n")
    for h in range(0, len(B)):
        print("\t" + str(B[h]))
    print("\n")
    D = [[0 for row in range(len(A))] for col in range(len(B[0]))]
    for x in range(0, len(A)):
        for y in range(0, len(A[0])):
            for z in range(0, len(A)):
                D[x][y] += A[x][z] * B[z][y]
    return D
