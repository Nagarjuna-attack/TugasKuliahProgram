totgenap = totganjil = 0
x = int(input(" Masukkan Bilangan X : "))
print(" \nBilangan genap 1 s/d %d adalah : " % x, end="")
for i in range(1, x + 1):
    if i % 2 == 0:
        totgenap += i
        print(i, end="")
print(" \nTotal Jumlahnya = %d" % totgenap)

print(" \nBilangan ganjil 1 s/d %d adalah : " % x, end="")
for i in range(1, x + 1):
    if i % 2 == 1:
        totganjil += i
        print(i, end="")
print(" Total Jumlahnya %d adalah : " % totganjil)
