bilangan1 = bilangan2 = luas = 0


def inputan(x, y):
    global bilangan1, bilangan2
    bilangan1 = int(input("Masukkan %s : " % x))
    bilangan2 = int(input("Masukkan %s : " % y))


def hitung():
    ls = bilangan1 * bilangan2
    return ls


def cetak(masukan):
    print("luas " + masukan + " : %d " % luas)


print("-----PROGRAM UNTUK MENGHITUNG LUAS-----")
print("1. Persegi Panjang")
print("2. Bujur Sangkar")
print("3. Segitiga")
print("4. Lingkaran")
pilih = input("Masukkan Pilihan anda : ")
if pilih == 1:
    print("PERSEGI PANJANG")
    inputan("Panjang", "Lebar")
    luas = hitung()
    cetak("Persegi Panjang")
elif pilih == 2:
    print("BUJUR SANGKAR")
    inputan("sisi1", "sisi2")
    luas = hitung()
    cetak("Bujur Sangkar")
elif pilih == 3:
    print("SEGITIGA")
    inputan("alas", "tinggi")
    luas = hitung()
    cetak("Segitiga")
elif pilih == 4:
    print("LINGKARAN")
    inputan("jari", "jari2")
    luas = hitung()
    cetak("Lingkaran")
