#proses pembuatan fungsi matematik
def penjumlahan(x, y):
    hasil = x + y
    print("Hasil Penjumlahan : %d" % hasil + "\n")


def pengurangan(x, y):
    hasil = x - y
    print("Hasil Pengurangan : %d" % hasil + "\n")


def perkalian(x, y):
    hasil = x * y
    print("Hasil Perkalian : %d" % hasil + "\n")


def pembagian(x, y):
    hasil = x / y
    print("Hasil Pembagian : %d" % hasil + "\n")


#semua fungsi operasi telah dibuat

print("\n")
print("---------------MENU---------------")
print("1. Penambahan")
print("2. Pengurangan")
print("3. Perkaliain")
print("4. Pembagian")
pilih = input("Masukkan pilihan : ")
if pilih == 1:
    print("PENJUMLAHAN\n")
    angka1 = input("Masukkan Angka pertama : ")
    angka2 = input("Masukkan Angka kedua : ")
    penjumlahan(angka1, angka2)
elif pilih == 2:
    print("PENGURANGAN\n")
    angka1 = input("Masukkan Angka pertama : ")
    angka2 = input("Masukkan Angka kedua : ")
    pengurangan(angka1, angka2)
elif pilih == 3:
    print("PERKALIAN\n")
    angka1 = input("Masukkan Angka pertama : ")
    angka2 = input("Masukkan Angka kedua : ")
    perkalian(angka1, angka2)
elif pilih == 4:
    print("PEMBAGIAN\n")
    angka1 = input("Masukkan Angka pertama : ")
    angka2 = input("Masukkan Angka kedua : ")
    pembagian(angka1, angka2)
elif pilih > 4:
    print("Oops..! ada kesalahan")
