print("\n")
print("sebuah bidang tanah sebagai berikut : ")
print("\t\t\t 50 M")
print("--------------------------------------------")
print("|                                          |")
print("|                                          |")
print("|                                          |40 M")
print("|                                          |")
print("|                                          |")
print("|                                          |")
print("|                                          |\t 30 M")
print("|                                          -----------------")
print("|                                                          |")
print("|                                                          |20 M")
print("|                                                          |")
print("------------------------------------------------------------")
print("\n")

kelilingpertama = (80 * 2) + (60 * 2)
kelilingdua = (40 * 2) + (30 * 2)
keliling = kelilingpertama - kelilingdua
luasTanah = (80 * 60) - (40 * 30)
rumah = 15 * 20
sumur = 3.14 * 0.5 * 0.5
rumahSumur = rumah + sumur
sisa_luas_tanah = luasTanah - rumahSumur

pondasi = int(input("Masukkan biaya Pemasangan Pondasi (per-M2) : "))
pagar = int(input("Masukkan biaya Pemasangan Pagar (per-M2) : "))
pavingBlock = int(input("Masukkan biaya Pemasangan Paving Block (per-M2) : "))

#menghitung biaya pemasangan pondasi pada pada sekeliling bidang tanah
biayaPondasi = pondasi * keliling
biayaPagar = pagar * keliling
biayaPavingBlock = pavingBlock * sisa_luas_tanah
print("\n")
print("Jumlah Keliling Bidang Adalah : %d M." % keliling)
print("Luas Bidang Sebelum Ada Bangunan Adalah : %d M persegi." % luasTanah)
print("Luas Bidang Setelah Ada Bangunan Adalah : %d M persegi." %
      sisa_luas_tanah)
print("Luas Bidang Bangunan Adalah : %d M persegi." % rumah)
print("Luas sumur Adalah : %s M persegi." % sumur)
print("\n")
print("Biaya Pagar Adalah  : Rp.%d M persegi." % biayaPagar)
print("Biaya Pondasi Adalah  : Rp.%d M persegi." % biayaPondasi)
print("Biaya PavingBlock Adalah  : Rp.%d M persegi." % biayaPavingBlock)