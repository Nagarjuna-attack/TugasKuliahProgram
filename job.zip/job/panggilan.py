import fungsi_pertama as afandi

afandi.perkalian(5, 6)
