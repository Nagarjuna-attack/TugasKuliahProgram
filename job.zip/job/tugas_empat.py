import fungsi_tugas_empat as fungsi
while 1:
    print("\tPILIH OPERASI MATRIKS")
    print("---------------------------------------")
    print("\t1. Scaleby")
    print("\t2. Transpose")
    print("\t3. Add")
    print("\t4. Subtract")
    print("\t5. Multiply")
    print("\t6. Exit")
    print("---------------------------------------")
    pilih = input("Masukkan Pilihan : ")
    if pilih == 1:
        print("\n\tScaleBy\n")
        hasil = fungsi.scaleBy()
        fungsi.output(hasil)
    elif pilih == 2:
        print("\n\tTranspose\n")
        hasil = fungsi.transpose()
        fungsi.output(hasil)
    elif pilih == 3:
        print("\n\tAdd\n")
        hasil = fungsi.add()
        fungsi.output(hasil)
    elif pilih == 4:
        print("\n\tSubtract\n")
        hasil = fungsi.subtract()
        fungsi.output(hasil)
    elif pilih == 5:
        print("\n\tMultiply\n")
        hasil = fungsi.multiply()
        fungsi.output(hasil)
    elif pilih == 6:
        print("Anda telah keluar dari program")
        exit()
else:
    print("\n")
print("Anda telah keluar dari program")
