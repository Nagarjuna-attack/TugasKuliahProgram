def afandi():
    print("hay afandi")


def ucapan(ucap):
    print(ucap)


def perkalian(x, y):
    hasil = x * y
    print("Hasil Perkalian dari %d" % x + " + %d" % y + " : %d" % hasil)


print(__name__)

#proses pembuatan fungsi pertama
