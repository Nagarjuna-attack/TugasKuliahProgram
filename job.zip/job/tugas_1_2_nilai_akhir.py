print("program untuk menghitung nilai akhir siswa\n")
nama = raw_input("Masukka nama Siswa : ")
nilaiAktif = int(input("Masukkan Nilai Keaktifan : "))
nilaiTugas = int(input("Masukkan Nilai Tugas : "))
nilaiUji = int(input("Masukkan Nilai Ujian : "))
#memproses nilai
nilaiAktif = nilaiAktif * 0.2  #nilai murni dari nilai Aktif didapatkan dari hasil pembagian 20%
nilaiTugas = nilaiTugas * 0.3  #nilai murni dari nilai Tugas didapatkan dari hasil pembagian 30%
nilaiUji = nilaiUji * 0.5  #nilai murni dari nilai Ujian didapatkan dari hasil pembagian 50%
nilaiAkhir = (nilaiAktif + nilaiTugas + nilaiUji)

#mencetak nilai
print("Nama Siswa : " + nama)
print("NIlai Akhir : %d" % nilaiAkhir)
