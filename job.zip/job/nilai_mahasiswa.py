import fungsi_nilai_mahasiswa as nilai
nilaimax = nilaimin = countA = countB = countC = countD = countE = jumdata = 0
stb_max = namamax = stb_min = namamin = ""
print("Program Untuk Menghitung Nilai Mahasiswa")
while 1:
    nilai_absen = pertemuan = nilai_tgs = nilai_mid = nilai_final = nilai_akhir = 0
    print("\n")
    stb = nilai.inbiodata("No Pokok : ")
    if stb == "x":
        break
    jumdata += 1
    nama = nilai.inbiodata("Nama : ")
    print("\nketerangan Nilai pertemuan ")
    print("0 = Tidak Hadir ")
    print("1 = Hadir \n")
    for i in range(1, 16):
        get = nilai.inputData("Pertemuan ke-%d :" % i)
        pertemuan += get
    pertemuan = float(pertemuan)
    print("\nMasukkan Nilai Tugas [0 s/d 100]\n")
    for i in range(1, 6):
        get = nilai.inputData("Nilai Tugas ke-%d : " % i)
        nilai_tgs += get
    print("\n")
    nilai_mid = nilai.inputData(" Nilai Mid [0 s/d 100] : ")
    nilai_final = nilai.inputData(" Nilai Final [0 s/d 100] : ")
    nilai_absen = nilai.validasi((pertemuan / 15), 100)
    murni_tgs = nilai_tgs / 5
    nilai_akhir = nilai.validasi(nilai_absen, 0.1) + nilai.validasi(
        murni_tgs, 0.2) + nilai.validasi(nilai_mid, 0.3) + nilai.validasi(
            nilai_final, 0.4)
    if nilaimin == 0:
        nilaimin = nilai_akhir
        namamin = nama
        stb_min = stb
    if nilai_akhir > nilaimax:
        nilaimax = nilai_akhir
        namamax = nama
        stb_max = stb
    if nilai_akhir < nilaimin:
        nilaimin = nilai_akhir
        namamin = nama
        stb_min = stb
    nilai_huruf = nilai.nilaiHuruf(nilai_akhir)
    if nilai_huruf == "A":
        countA += 1
    elif nilai_huruf == "B":
        countB += 1
    elif nilai_huruf == "C":
        countC += 1
    elif nilai_huruf == "D":
        countD += 1
    elif nilai_huruf == "E":
        countE += 1
    keterangan = nilai.keterangan(nilai_huruf)
    print("\nData ke-%d" % jumdata)
    print("No Pokok : " + stb)
    print("Nama       : " + nama)
    print("Nilai Absensi     : %d" % nilai_absen)
    print("Nilai Murni Tugas : %d" % murni_tgs)
    print("Nilai Mid         : %d" % nilai_mid)
    print("Nilai Final       : %d" % nilai_final)
    print("Nilai Akhir       : %d" % nilai_akhir)
    print("Nilai Huruf       : %s" % nilai_huruf)
    print("KETERANGAN        : %s" % keterangan)
else:
    print("\n")
print("\nProgram Berakhir....!\n")
print("Jumlah Data Mahasiswa : %d" % jumdata)
print("\nMahasiswa dengan Nilai Akhir Maksimum \n")
print("Nama : %s" % namamax)
print("No Pokok : %s" % stb_max)
print("Nilai Akhir : %d" % nilaimax)
print("\n")
print("Mahasiswa dengan  Nilai Akhir Minimum \n")
print("Nama : %s" % namamin)
print("No Pokok : %s" % stb_min)
print("Nilai Akhir : %d" % nilaimin)
print("\n")
print("Mahasiswa dengan Nilai A : %d" % countA)
print("Mahasiswa dengan Nilai B : %d" % countB)
print("Mahasiswa dengan Nilai C : %d" % countC)
print("Mahasiswa dengan Nilai D : %d" % countD)
print("Mahasiswa dengan Nilai E : %d" % countE)
print("\n")