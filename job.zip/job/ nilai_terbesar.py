#program untuk mencari nilai terbesar
terbesar = 0
while 1:
    bil = int(input(" Masukkan nilai [0 = exit] : "))
    if bil > terbesar:
        terbesar = bil
    if bil == 0:
        break
else:
    print()
print(" Nilai Terbesar Adalah : %d" % terbesar)
