gaji = 2500000
nama = raw_input(" Masukkan nama anda : ")
nik = raw_input(" Masukkan nik anda : ")
status = raw_input(" Masukkan status perkawinan [M=menikah/B=belum] : ")
if status == 'M':
    jumanak = int(input(" Masukkan Jumlah Anak : "))
    tkel = 0.15 * gaji
    if jumanak <= 3:
        tanak = (0.05 * gaji) * jumanak
    else:
        tanak = (0.05 * gaji) * 3
else:
    tkel = tanak = 0

print("-" * 35)
print("Nama Karyawan : " + nama)
print("N I K : " + nik)
print("Gaji Pokok : %10d" % gaji)
print("Tunjangan Keluarga : %10d" % tkel)
print("Tunjangan Anak : %10d" % tanak)
gaji_bersih = gaji + tkel + tanak
print("Gaji Bersih : %10d" % gaji_bersih)
