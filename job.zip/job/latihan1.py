#menampilkan bilangan terbesar

a = int(input("Masukkan bilangan pertama : "))
b = int(input("Masukkan bilangan kedua : "))
terbesar = a
if terbesar < b:
    terbesar = b
    print("Bilangan Terbesar adalah : %d" % terbesar)
elif terbesar > a:
    print("bilangan terbesar adalah %d" % a)
else:
    print("tidak ada yang benar")
